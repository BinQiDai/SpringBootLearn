package com.abc.service;

/**
 * @desc:
 * @author: BinQi.Dai
 * @date: 2020/12/23
 */
public interface SomeService {
    String hello();
}
